const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!res.ok) {
    let detail = "Something went wrong";
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch {
      // ignore
    }
    throw new Error(detail);
  }

  return res.json();
}

export const api = {
  login: (studentId) =>
    request("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ student_id: studentId }),
    }),

  getMenu: (week, includeStaples = true) => {
    const params = new URLSearchParams();
    if (week !== undefined && week !== null) params.set("week", week);
    params.set("include_staples", includeStaples);
    return request(`/api/menu?${params.toString()}`);
  },

  getVoteStatus: (studentId, week) =>
    request(`/api/votes/${studentId}?week=${week}`),

  toggleVote: (studentId, menuItemId, week) =>
    request("/api/votes/toggle", {
      method: "POST",
      body: JSON.stringify({ student_id: studentId, menu_item_id: menuItemId, week }),
    }),

  getNotifications: (studentId) => request(`/api/notifications/${studentId}`),

  checkIn: (studentId, menuItemId) =>
    request("/api/checkin", {
      method: "POST",
      body: JSON.stringify({ student_id: studentId, menu_item_id: menuItemId }),
    }),

  getCheckins: (studentId) => request(`/api/checkins/${studentId}`),

  rate: (studentId, menuItemId, rating, wasteFlag, feedback) =>
    request("/api/rate", {
      method: "POST",
      body: JSON.stringify({
        student_id: studentId,
        menu_item_id: menuItemId,
        rating,
        waste_flag: wasteFlag,
        feedback,
      }),
    }),

  adminCreateMenuItem: (item) =>
    request("/api/admin/menu", {
      method: "POST",
      body: JSON.stringify(item),
    }),

  adminUpdateMenuItem: (id, payload) =>
    request(`/api/admin/menu/${id}`, {
      method: "PATCH",
      body: JSON.stringify(payload),
    }),

  adminDeleteMenuItem: (id) =>
    request(`/api/admin/menu/${id}`, { method: "DELETE" }),

  adminDashboard: () => request("/api/admin/dashboard"),

  getVotingWindow: (week) => request(`/api/admin/voting-window?week=${week}`),

  updateVotingWindow: (week, payload) =>
    request(`/api/admin/voting-window?week=${week}`, {
      method: "PATCH",
      body: JSON.stringify(payload),
    }),

  adminLogWaste: (payload) =>
    request("/api/admin/waste", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  adminListWaste: () => request("/api/admin/waste"),

  preferenceReport: () => request("/api/admin/reports/preferences"),

  sustainabilityReport: () => request("/api/admin/reports/sustainability"),
};

export const WEEKS = {
  SERVED: 1,
  VOTING: 2,
};

export const VOTE_CATEGORIES = ["breakfast", "lunch", "snacks", "dinner", "dessert"];

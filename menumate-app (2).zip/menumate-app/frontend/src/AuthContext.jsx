import { createContext, useContext, useEffect, useState } from "react";
import { api } from "./api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedId = localStorage.getItem("menumate_student_id");
    if (savedId) {
      api
        .login(savedId)
        .then(setUser)
        .catch(() => localStorage.removeItem("menumate_student_id"))
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (studentId) => {
    const student = await api.login(studentId);
    localStorage.setItem("menumate_student_id", student.id);
    setUser(student);
    return student;
  };

  const logout = () => {
    localStorage.removeItem("menumate_student_id");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

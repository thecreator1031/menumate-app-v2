import { Heart, Lock, Users, UtensilsCrossed } from "lucide-react";
import DietBadge from "./DietBadge";

export default function VoteCard({ item, onToggle, busy }) {
  const voted = item.voted_by_me;
  const locked = item.is_locked;

  return (
    <div
      className={`flex flex-col overflow-hidden rounded-2xl border transition-colors ${
        locked
          ? "border-surface-border bg-surface/50 opacity-80"
          : voted
          ? "border-accent-400/40 bg-surface"
          : "border-surface-border bg-surface"
      }`}
    >
      <div className="flex h-32 items-center justify-center bg-surface-raised text-ash-600">
        {item.image_url ? (
          <img
            src={item.image_url}
            alt={item.name}
            className="h-full w-full object-cover"
          />
        ) : (
          <UtensilsCrossed size={28} />
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex flex-wrap items-center gap-1.5">
          <h3 className="font-display text-sm font-semibold text-ash-100">
            {item.name}
          </h3>
          <DietBadge tag={item.dietary_tag} />
        </div>

        {item.description && (
          <p className="text-xs leading-relaxed text-ash-400">
            {item.description}
          </p>
        )}

        {locked && (
          <span className="inline-flex w-fit items-center gap-1 rounded-full bg-saffron-400/10 px-2.5 py-1 text-xs font-medium text-saffron-400">
            <Lock size={12} />
            Crowd favorite — locked in
          </span>
        )}

        <p className="mt-auto flex items-center gap-1.5 pt-1 text-xs text-ash-500">
          <Users size={12} />
          {item.total_votes} vote{item.total_votes === 1 ? "" : "s"}
        </p>

        <button
          type="button"
          onClick={() => onToggle(item.id)}
          disabled={locked || busy}
          className={`mt-1 inline-flex w-full items-center justify-center gap-2 rounded-xl border px-3 py-2 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${
            voted
              ? "border-accent-400/40 bg-accent-400/10 text-accent-400"
              : "border-surface-border text-ash-300 hover:border-accent-400/40 hover:text-accent-400"
          }`}
        >
          <Heart size={15} className={voted ? "fill-accent-400" : ""} />
          {voted ? "Voted" : "Vote"}
        </button>
      </div>
    </div>
  );
}

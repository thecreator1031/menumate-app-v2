import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import {
  Leaf,
  Heart,
  ClipboardList,
  QrCode,
  Settings,
  BarChart3,
  LineChart,
  Bell,
  LogOut,
} from "lucide-react";
import { useAuth } from "../AuthContext";
import { api } from "../api";

const STUDENT_LINKS = [
  { to: "/vote", label: "Vote", icon: Heart },
  { to: "/menu", label: "Menu", icon: ClipboardList },
  { to: "/checkin", label: "Check-in", icon: QrCode },
];

const ADMIN_LINKS = [
  { to: "/admin/menu", label: "Menu & Voting", icon: Settings },
  { to: "/admin/dashboard", label: "Results", icon: BarChart3 },
  { to: "/admin/analytics", label: "Analytics", icon: LineChart },
];

export default function Navbar() {
  const { user, logout } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const links = user?.role === "admin" ? ADMIN_LINKS : STUDENT_LINKS;

  useEffect(() => {
    if (user?.role === "student") {
      api
        .getNotifications(user.id)
        .then(setNotifications)
        .catch(() => setNotifications([]));
    }
  }, [user?.id, user?.role]);

  return (
    <header className="sticky top-0 z-30 border-b border-surface-border bg-ink/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <NavLink to="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent-400/10 text-accent-400">
            <Leaf size={18} />
          </span>
          <span className="font-display text-lg font-semibold tracking-tight text-ash-100">
            MenuMate
          </span>
        </NavLink>

        {user && (
          <nav className="hidden items-center gap-1 sm:flex">
            {links.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-surface-raised text-accent-400"
                      : "text-ash-400 hover:text-ash-100"
                  }`
                }
              >
                <Icon size={16} />
                {label}
              </NavLink>
            ))}
          </nav>
        )}

        {user ? (
          <div className="flex items-center gap-3">
            {user.role === "student" && (
              <div className="relative">
                <button
                  onClick={() => setShowNotifications((s) => !s)}
                  className="relative flex h-9 w-9 items-center justify-center rounded-lg border border-surface-border text-ash-400 transition-colors hover:text-ash-100"
                >
                  <Bell size={16} />
                  {notifications.length > 0 && (
                    <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-accent-400 text-[10px] font-bold text-ink">
                      {notifications.length}
                    </span>
                  )}
                </button>
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-72 rounded-2xl border border-surface-border bg-surface p-3 shadow-xl">
                    <p className="px-1 pb-2 text-xs font-semibold uppercase tracking-wide text-ash-500">
                      Notifications
                    </p>
                    {notifications.length === 0 ? (
                      <p className="px-1 py-2 text-sm text-ash-400">
                        Nothing new right now.
                      </p>
                    ) : (
                      <div className="flex flex-col gap-2">
                        {notifications.map((n) => (
                          <div
                            key={n.id}
                            className="rounded-xl border border-surface-border bg-surface-raised p-2.5"
                          >
                            <p className="text-sm font-medium text-ash-100">
                              {n.title}
                            </p>
                            <p className="mt-0.5 text-xs text-ash-400">
                              {n.body}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
            <div className="hidden text-right sm:block">
              <p className="text-sm font-medium text-ash-100">{user.name}</p>
              <p className="text-xs uppercase tracking-wide text-ash-500">
                {user.role === "admin" ? "Admin" : user.id}
              </p>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-2 rounded-lg border border-surface-border px-3 py-2 text-sm font-medium text-ash-400 transition-colors hover:border-coral-400/40 hover:text-coral-400"
            >
              <LogOut size={16} />
              <span className="hidden sm:inline">Log out</span>
            </button>
          </div>
        ) : (
          <NavLink
            to="/login"
            className="rounded-lg bg-accent-400 px-4 py-2 text-sm font-semibold text-ink transition-colors hover:bg-accent-200"
          >
            Log in
          </NavLink>
        )}
      </div>

      {/* Mobile nav links */}
      {user && (
        <nav className="flex items-center gap-1 overflow-x-auto border-t border-surface-border px-4 py-2 sm:hidden">
          {links.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-surface-raised text-accent-400"
                    : "text-ash-400 hover:text-ash-100"
                }`
              }
            >
              <Icon size={15} />
              {label}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  );
}

import { Utensils } from "lucide-react";

export default function StaplesBanner({ staples }) {
  if (!staples || staples.length === 0) return null;

  return (
    <div className="rounded-2xl border border-surface-border bg-surface/60 p-4">
      <div className="flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent-400/10 text-accent-400">
          <Utensils size={15} />
        </span>
        <div>
          <h3 className="font-display text-sm font-semibold text-ash-100">
            Always on the table
          </h3>
          <p className="text-xs text-ash-500">
            Served daily, no voting needed — for everyone, including anyone
            who skips the voted menu.
          </p>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {staples.map((item) => (
          <span
            key={item.id}
            className="rounded-full border border-surface-border bg-surface px-3 py-1.5 text-xs font-medium text-ash-300"
            title={item.description}
          >
            {item.name}
          </span>
        ))}
      </div>
    </div>
  );
}

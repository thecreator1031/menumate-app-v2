import { useEffect, useState } from "react";
import { Clock } from "lucide-react";

function formatRemaining(ms) {
  if (ms <= 0) return "00h 00m 00s";
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  return `${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
}

export default function CountdownTimer({ closesAt, isOpen }) {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  if (!closesAt) return null;

  const target = new Date(closesAt).getTime();
  const remaining = target - now;
  const closed = !isOpen || remaining <= 0;

  return (
    <div className="flex items-center gap-2">
      <Clock size={16} className="text-accent-400" />
      <div>
        <p className="text-xs text-ash-400">
          {closed ? "Voting closed" : "Voting ends in"}
        </p>
        {!closed && (
          <p className="font-mono text-sm font-semibold text-accent-400">
            {formatRemaining(remaining)}
          </p>
        )}
      </div>
    </div>
  );
}

const STYLES = {
  veg: {
    label: "Veg",
    dot: "bg-accent-400",
    text: "text-accent-400",
    ring: "ring-accent-400/30",
  },
  non_veg: {
    label: "Non-veg",
    dot: "bg-coral-400",
    text: "text-coral-400",
    ring: "ring-coral-400/30",
  },
  jain: {
    label: "Jain",
    dot: "bg-saffron-400",
    text: "text-saffron-400",
    ring: "ring-saffron-400/30",
  },
};

export default function DietBadge({ tag, className = "" }) {
  const style = STYLES[tag] || STYLES.veg;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full bg-surface-raised px-2.5 py-1 text-xs font-medium ring-1 ${style.ring} ${style.text} ${className}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${style.dot}`} />
      {style.label}
    </span>
  );
}

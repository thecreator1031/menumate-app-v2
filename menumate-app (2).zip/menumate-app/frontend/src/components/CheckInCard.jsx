import { useState } from "react";
import { QrCode, Star, Trash2, CheckCircle2, MessageSquare } from "lucide-react";
import DietBadge from "./DietBadge";

export default function CheckInCard({ item, checkin, onCheckIn, onRate }) {
  const [rating, setRating] = useState(checkin?.rating || 0);
  const [wasteFlag, setWasteFlag] = useState(checkin?.waste_flag || false);
  const [feedback, setFeedback] = useState(checkin?.feedback || "");
  const [busy, setBusy] = useState(false);

  const isCheckedIn = Boolean(checkin);
  const isRated = checkin?.rating != null;

  const handleCheckIn = async () => {
    setBusy(true);
    try {
      await onCheckIn(item.id);
    } finally {
      setBusy(false);
    }
  };

  const handleRate = async () => {
    setBusy(true);
    try {
      await onRate(item.id, rating, wasteFlag, feedback);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-2xl border border-surface-border bg-surface p-5">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="font-display text-base font-semibold text-ash-100">
          {item.name}
        </h3>
        <DietBadge tag={item.dietary_tag} />
        <span className="rounded-full bg-surface-raised px-2.5 py-1 text-xs font-medium text-ash-500">
          {item.category}
        </span>
      </div>
      {item.description && (
        <p className="mt-1.5 text-sm text-ash-400">{item.description}</p>
      )}

      <div className="mt-4">
        {!isCheckedIn && (
          <button
            onClick={handleCheckIn}
            disabled={busy}
            className="inline-flex items-center gap-2 rounded-xl bg-accent-400 px-4 py-2.5 text-sm font-semibold text-ink transition-colors hover:bg-accent-200 disabled:opacity-50"
          >
            <QrCode size={16} />
            {busy ? "Checking in…" : "Check in"}
          </button>
        )}

        {isCheckedIn && !isRated && (
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2 text-sm text-accent-400">
                <CheckCircle2 size={16} />
                Checked in — rate this plate
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      onClick={() => setRating(n)}
                      className="text-ash-500 transition-colors hover:text-saffron-400"
                    >
                      <Star
                        size={20}
                        className={
                          n <= rating
                            ? "fill-saffron-400 text-saffron-400"
                            : ""
                        }
                      />
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setWasteFlag((w) => !w)}
                  className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                    wasteFlag
                      ? "border-coral-400/40 bg-coral-400/10 text-coral-400"
                      : "border-surface-border text-ash-500 hover:text-ash-300"
                  }`}
                >
                  <Trash2 size={14} />
                  Leftovers
                </button>
              </div>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
              <div className="relative flex-1">
                <MessageSquare
                  size={14}
                  className="pointer-events-none absolute left-3 top-3 text-ash-500"
                />
                <textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Optional: leave feedback or suggestions for next time"
                  rows={2}
                  className="w-full resize-none rounded-xl border border-surface-border bg-surface-raised pl-9 pr-3 py-2.5 text-sm text-ash-100 placeholder:text-ash-500 focus:border-accent-400"
                />
              </div>
              <button
                onClick={handleRate}
                disabled={busy || rating === 0}
                className="rounded-lg bg-accent-400 px-4 py-2.5 text-sm font-semibold text-ink transition-colors hover:bg-accent-200 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {busy ? "Saving…" : "Submit"}
              </button>
            </div>
          </div>
        )}

        {isRated && (
          <div className="flex flex-col gap-2">
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <span className="inline-flex items-center gap-1.5 text-accent-400">
                <CheckCircle2 size={16} />
                Rated {checkin.rating}/5
              </span>
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <Star
                    key={n}
                    size={14}
                    className={
                      n <= checkin.rating
                        ? "fill-saffron-400 text-saffron-400"
                        : "text-ash-600"
                    }
                  />
                ))}
              </div>
              {checkin.waste_flag && (
                <span className="inline-flex items-center gap-1.5 rounded-full bg-coral-400/10 px-2.5 py-1 text-xs text-coral-400">
                  <Trash2 size={12} />
                  Leftovers flagged
                </span>
              )}
            </div>
            {checkin.feedback && (
              <p className="rounded-xl border border-surface-border bg-surface-raised p-2.5 text-sm text-ash-400">
                <MessageSquare size={12} className="mr-1.5 inline" />
                {checkin.feedback}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Leaf, ArrowRight } from "lucide-react";
import Navbar from "../components/Navbar";
import { useAuth } from "../AuthContext";

const DEMO_STUDENTS = [
  { id: "S1001", name: "Aanya" },
  { id: "S1002", name: "Rohan" },
  { id: "S1003", name: "Kabir" },
  { id: "S1004", name: "Priya" },
  { id: "S1005", name: "Arjun" },
  { id: "S1006", name: "Diya" },
];

export default function Login() {
  const [studentId, setStudentId] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (id) => {
    setError("");
    setLoading(true);
    try {
      const student = await login(id);
      navigate(student.role === "admin" ? "/admin/dashboard" : "/vote");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto flex max-w-md flex-col px-6 pt-16 sm:pt-24">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent-400/10 text-accent-400">
          <Leaf size={22} />
        </span>
        <h1 className="mt-6 font-display text-3xl font-semibold text-ash-100">
          Log in to MenuMate
        </h1>
        <p className="mt-2 text-sm text-ash-400">
          Enter your student ID, or pick a demo account below to explore the
          app.
        </p>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (studentId.trim()) handleLogin(studentId.trim());
          }}
          className="mt-8 flex flex-col gap-3"
        >
          <input
            type="text"
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            placeholder="e.g. S1001 or ADMIN1"
            className="rounded-xl border border-surface-border bg-surface px-4 py-3 text-sm text-ash-100 placeholder:text-ash-500 focus:border-accent-400"
          />
          <button
            type="submit"
            disabled={loading || !studentId.trim()}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-accent-400 px-4 py-3 text-sm font-semibold text-ink transition-colors hover:bg-accent-200 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? "Logging in…" : "Continue"}
            <ArrowRight size={16} />
          </button>
        </form>

        {error && (
          <p className="mt-3 rounded-lg border border-coral-400/30 bg-coral-400/10 px-3 py-2 text-sm text-coral-400">
            {error}
          </p>
        )}

        <div className="mt-10">
          <p className="text-xs uppercase tracking-wide text-ash-500">
            Demo student accounts
          </p>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {DEMO_STUDENTS.map((s) => (
              <button
                key={s.id}
                onClick={() => handleLogin(s.id)}
                className="rounded-xl border border-surface-border bg-surface px-3 py-2.5 text-left transition-colors hover:border-accent-400/40"
              >
                <p className="text-sm font-medium text-ash-100">{s.id}</p>
                <p className="text-xs text-ash-500">{s.name}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4">
          <button
            onClick={() => handleLogin("ADMIN1")}
            className="w-full rounded-xl border border-surface-border bg-surface px-3 py-2.5 text-left transition-colors hover:border-saffron-400/40"
          >
            <p className="text-sm font-medium text-ash-100">ADMIN1</p>
            <p className="text-xs text-ash-500">Mess admin dashboard</p>
          </button>
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Users, Trash2, Wallet, Star, Lock } from "lucide-react";
import Navbar from "../components/Navbar";
import DietBadge from "../components/DietBadge";
import CountdownTimer from "../components/CountdownTimer";
import { api } from "../api";

const TAG_COLORS = {
  veg: "#34D399",
  non_veg: "#FB7185",
  jain: "#FBBF24",
};

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .adminDashboard()
      .then(setData)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex min-h-[60vh] items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-surface-border border-t-accent-400" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="mx-auto max-w-4xl px-6 py-10">
          <p className="rounded-lg border border-coral-400/30 bg-coral-400/10 px-3 py-2 text-sm text-coral-400">
            {error || "Could not load dashboard"}
          </p>
        </div>
      </div>
    );
  }

  const chartData = data.vote_summary.map((item) => ({
    name: item.name,
    votes: item.total_votes,
    color: TAG_COLORS[item.dietary_tag] || "#34D399",
  }));

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto max-w-5xl px-6 py-10">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold text-ash-100">
              Results dashboard
            </h1>
            <p className="mt-1 text-sm text-ash-400">
              Week {data.current_week} performance, and live demand for week{" "}
              {data.voting_week}.
            </p>
          </div>
          {data.window && (
            <div className="rounded-2xl border border-surface-border bg-surface px-4 py-3">
              <CountdownTimer
                closesAt={data.window.closes_at}
                isOpen={data.window.is_open}
              />
            </div>
          )}
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <KpiCard
            icon={Users}
            label="Turnout"
            value={`${data.turnout_pct}%`}
            sub={`${data.total_checkins} check-ins · ${data.total_students} students`}
          />
          <KpiCard
            icon={Trash2}
            label="Waste rate"
            value={`${data.waste_pct}%`}
            sub={`${data.waste_kg_total} kg logged in total`}
            accent="coral"
          />
          <KpiCard
            icon={Wallet}
            label="Cost per plate"
            value={`${data.cost_per_plate}x`}
            sub="Relative to a baseline dish"
            accent="saffron"
          />
          <KpiCard
            icon={Star}
            label="Satisfaction index"
            value={`${data.satisfaction_index} / 5`}
            sub="Average rating across check-ins"
          />
        </div>

        <div className="mt-8 rounded-2xl border border-surface-border bg-surface p-5">
          <h2 className="font-display text-sm font-semibold uppercase tracking-wide text-ash-500">
            Live vote tally for week {data.voting_week}
          </h2>
          <div className="mt-4 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ left: -20, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2B2B27" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fill: "#A3A39E", fontSize: 11 }}
                  axisLine={{ stroke: "#2B2B27" }}
                  tickLine={false}
                  interval={0}
                  angle={-20}
                  textAnchor="end"
                  height={60}
                />
                <YAxis
                  tick={{ fill: "#A3A39E", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  contentStyle={{
                    background: "#1C1C19",
                    border: "1px solid #2B2B27",
                    borderRadius: "0.75rem",
                    fontSize: "0.8rem",
                  }}
                  labelStyle={{ color: "#F5F5F4" }}
                  cursor={{ fill: "rgba(255,255,255,0.03)" }}
                />
                <Bar dataKey="votes" radius={[6, 6, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="mt-8">
          <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ash-500">
            Week {data.voting_week} candidate breakdown
          </h2>
          <div className="space-y-2">
            {data.vote_summary.map((item) => (
              <div
                key={item.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-surface-border bg-surface p-4"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-display text-sm font-semibold text-ash-100">
                    {item.name}
                  </h3>
                  <DietBadge tag={item.dietary_tag} />
                  <span className="rounded-full bg-surface-raised px-2.5 py-1 text-xs font-medium text-ash-500">
                    {item.category}
                  </span>
                  {item.is_locked && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-saffron-400/10 px-2.5 py-1 text-xs font-medium text-saffron-400">
                      <Lock size={12} />
                      Locked
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-4 font-mono text-sm text-ash-300">
                  <span>
                    {item.total_votes} vote{item.total_votes === 1 ? "" : "s"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, sub, accent = "accent" }) {
  const accentClasses = {
    accent: "bg-accent-400/10 text-accent-400",
    coral: "bg-coral-400/10 text-coral-400",
    saffron: "bg-saffron-400/10 text-saffron-400",
  };
  return (
    <div className="rounded-2xl border border-surface-border bg-surface p-5">
      <span
        className={`flex h-9 w-9 items-center justify-center rounded-xl ${accentClasses[accent]}`}
      >
        <Icon size={18} />
      </span>
      <p className="mt-3 font-display text-2xl font-semibold text-ash-100">
        {value}
      </p>
      <p className="text-sm font-medium text-ash-300">{label}</p>
      <p className="mt-1 text-xs text-ash-500">{sub}</p>
    </div>
  );
}

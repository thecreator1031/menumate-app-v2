import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import CheckInCard from "../components/CheckInCard";
import StaplesBanner from "../components/StaplesBanner";
import { api, WEEKS, VOTE_CATEGORIES } from "../api";
import { useAuth } from "../AuthContext";

const CATEGORY_LABELS = {
  breakfast: "Breakfast",
  lunch: "Lunch",
  snacks: "Snacks",
  dinner: "Dinner",
  dessert: "Desserts",
};

export default function CheckIn() {
  const { user } = useAuth();
  const [menu, setMenu] = useState([]);
  const [staples, setStaples] = useState([]);
  const [checkins, setCheckins] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([
      api.getMenu(WEEKS.SERVED, true),
      api.getCheckins(user.id),
    ])
      .then(([menuData, checkinData]) => {
        setMenu(menuData.filter((i) => !i.is_staple));
        setStaples(menuData.filter((i) => i.is_staple));
        const map = {};
        checkinData.forEach((c) => {
          map[c.menu_item_id] = c;
        });
        setCheckins(map);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [user.id]);

  const handleCheckIn = async (menuItemId) => {
    const record = await api.checkIn(user.id, menuItemId);
    setCheckins((prev) => ({ ...prev, [menuItemId]: record }));
  };

  const handleRate = async (menuItemId, rating, wasteFlag, feedback) => {
    const record = await api.rate(user.id, menuItemId, rating, wasteFlag, feedback);
    setCheckins((prev) => ({ ...prev, [menuItemId]: record }));
  };

  const grouped = menu.reduce((acc, item) => {
    acc[item.category] = acc[item.category] || [];
    acc[item.category].push(item);
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex min-h-[60vh] items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-surface-border border-t-accent-400" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto max-w-4xl px-6 py-10">
        <h1 className="font-display text-3xl font-semibold text-ash-100">
          This week's meals
        </h1>
        <p className="mt-1 text-sm text-ash-400">
          Check in when you collect your plate, then rate it afterwards.
        </p>

        {error && (
          <p className="mt-4 rounded-lg border border-coral-400/30 bg-coral-400/10 px-3 py-2 text-sm text-coral-400">
            {error}
          </p>
        )}

        <div className="mt-6">
          <StaplesBanner staples={staples} />
        </div>

        <div className="mt-8 space-y-8">
          {VOTE_CATEGORIES.filter((cat) => grouped[cat]?.length).map((category) => (
            <div key={category}>
              <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ash-500">
                {CATEGORY_LABELS[category] || category}
              </h2>
              <div className="space-y-3">
                {grouped[category].map((item) => (
                  <CheckInCard
                    key={item.id}
                    item={item}
                    checkin={checkins[item.id]}
                    onCheckIn={handleCheckIn}
                    onRate={handleRate}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

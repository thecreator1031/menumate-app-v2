import { useEffect, useMemo, useState } from "react";
import { Users, ShieldCheck } from "lucide-react";
import Navbar from "../components/Navbar";
import VoteCard from "../components/VoteCard";
import DietBadge from "../components/DietBadge";
import CountdownTimer from "../components/CountdownTimer";
import StaplesBanner from "../components/StaplesBanner";
import { api, WEEKS, VOTE_CATEGORIES } from "../api";
import { useAuth } from "../AuthContext";

const CATEGORY_LABELS = {
  breakfast: "Breakfast",
  lunch: "Lunch",
  snacks: "Snacks",
  dinner: "Dinner",
  dessert: "Desserts",
};

export default function Vote() {
  const { user } = useAuth();
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    api
      .getVoteStatus(user.id, WEEKS.VOTING)
      .then(setStatus)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [user.id]);

  const grouped = useMemo(() => {
    if (!status) return {};
    return status.items.reduce((acc, item) => {
      acc[item.category] = acc[item.category] || [];
      acc[item.category].push(item);
      return acc;
    }, {});
  }, [status]);

  const totalParticipants = useMemo(() => {
    if (!status) return 0;
    const voters = new Set();
    // total_votes per item is a count, not voter ids — approximate using max
    return status.items.reduce((max, item) => Math.max(max, item.total_votes), 0);
  }, [status]);

  const handleToggle = async (itemId) => {
    setBusyId(itemId);
    setError("");
    try {
      const updated = await api.toggleVote(user.id, itemId, WEEKS.VOTING);
      setStatus(updated);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex min-h-[60vh] items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-surface-border border-t-accent-400" />
        </div>
      </div>
    );
  }

  const window_ = status?.window;
  const votingClosed = window_ && !window_.is_open;

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto max-w-6xl px-6 py-10">
        <div className="flex flex-wrap items-center justify-between gap-3 text-center sm:text-left">
          <div className="w-full sm:w-auto">
            <h1 className="font-display text-3xl font-semibold text-ash-100 sm:text-4xl">
              Vote on <span className="text-accent-400">Next Week's</span> Menu
            </h1>
            <p className="mt-1 text-sm text-ash-400">
              Select your favorites — your votes decide what gets cooked.
            </p>
          </div>
          <DietBadge tag={user.dietary_pref} />
        </div>

        {error && (
          <p className="mt-4 rounded-lg border border-coral-400/30 bg-coral-400/10 px-3 py-2 text-sm text-coral-400">
            {error}
          </p>
        )}

        {/* Status bar */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-6 rounded-2xl border border-accent-400/20 bg-accent-400/5 p-5">
          <CountdownTimer closesAt={window_?.closes_at} isOpen={window_?.is_open} />
          <div className="flex items-center gap-2">
            <Users size={16} className="text-accent-400" />
            <div>
              <p className="text-xs text-ash-400">Total votes cast</p>
              <p className="font-mono text-sm font-semibold text-accent-400">
                {totalParticipants}
              </p>
            </div>
          </div>
        </div>

        {votingClosed && (
          <p className="mt-4 rounded-lg border border-saffron-400/30 bg-saffron-400/10 px-3 py-2 text-sm text-saffron-400">
            Voting is closed for this week — results are being finalized by
            the mess committee.
          </p>
        )}

        {/* Daily staples */}
        <div className="mt-6">
          <StaplesBanner staples={status.staples} />
        </div>

        {/* Voted categories */}
        <div className="mt-8 space-y-10">
          {VOTE_CATEGORIES.filter((cat) => grouped[cat]?.length).map((category) => (
            <div key={category}>
              <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ash-500">
                {CATEGORY_LABELS[category] || category}
              </h2>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {grouped[category].map((item) => (
                  <VoteCard
                    key={item.id}
                    item={item}
                    onToggle={handleToggle}
                    busy={busyId === item.id || votingClosed}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 flex items-center justify-center gap-2 rounded-2xl border border-accent-400/20 bg-accent-400/5 p-4 text-sm text-accent-400">
          <ShieldCheck size={16} />
          Your vote helps choose the menu for everyone. Choose wisely!
        </div>
      </div>
    </div>
  );
}

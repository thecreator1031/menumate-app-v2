import { useEffect, useState } from "react";
import {
  Lock,
  Unlock,
  Trash2,
  Plus,
  PlayCircle,
  PauseCircle,
  Megaphone,
  Clock4,
} from "lucide-react";
import Navbar from "../components/Navbar";
import DietBadge from "../components/DietBadge";
import CountdownTimer from "../components/CountdownTimer";
import { api, WEEKS, VOTE_CATEGORIES } from "../api";

const CATEGORIES = [...VOTE_CATEGORIES, "staple"];
const DIET_TAGS = ["veg", "non_veg", "jain"];

const emptyForm = {
  name: "",
  description: "",
  category: "lunch",
  dietary_tag: "veg",
  cost_weight: 1,
  week: WEEKS.VOTING,
  is_staple: false,
};

export default function AdminMenu() {
  const [items, setItems] = useState([]);
  const [window_, setWindow] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [windowBusy, setWindowBusy] = useState(false);

  const load = () => {
    Promise.all([
      api.getMenu(WEEKS.SERVED, true),
      api.getMenu(WEEKS.VOTING, true),
      api.getVotingWindow(WEEKS.VOTING).catch(() => null),
    ])
      .then(([served, voting, vw]) => {
        setItems([...served, ...voting]);
        setWindow(vw);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const toggleLock = async (item) => {
    const updated = await api.adminUpdateMenuItem(item.id, {
      is_locked: !item.is_locked,
    });
    setItems((prev) => prev.map((i) => (i.id === item.id ? updated : i)));
  };

  const remove = async (item) => {
    await api.adminDeleteMenuItem(item.id);
    setItems((prev) => prev.filter((i) => i.id !== item.id));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      const created = await api.adminCreateMenuItem({
        ...form,
        cost_weight: Number(form.cost_weight),
        week: Number(form.week),
        category: form.is_staple ? "staple" : form.category,
      });
      setItems((prev) => [...prev, created]);
      setForm(emptyForm);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const updateWindow = async (payload) => {
    setWindowBusy(true);
    setError("");
    try {
      const updated = await api.updateVotingWindow(WEEKS.VOTING, payload);
      setWindow(updated);
    } catch (err) {
      setError(err.message);
    } finally {
      setWindowBusy(false);
    }
  };

  const extendByHours = (hours) => {
    if (!window_) return;
    const base = new Date(window_.closes_at).getTime();
    const closes_at = new Date(base + hours * 3600 * 1000).toISOString();
    updateWindow({ closes_at });
  };

  const served = items.filter((i) => i.week === WEEKS.SERVED);
  const voting = items.filter((i) => i.week === WEEKS.VOTING);

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto max-w-4xl px-6 py-10">
        <h1 className="font-display text-3xl font-semibold text-ash-100">
          Menu & voting setup
        </h1>
        <p className="mt-1 text-sm text-ash-400">
          Manage what's being served now, control the voting window for next
          week, and publish the final menu once decided.
        </p>

        {error && (
          <p className="mt-4 rounded-lg border border-coral-400/30 bg-coral-400/10 px-3 py-2 text-sm text-coral-400">
            {error}
          </p>
        )}

        {loading ? (
          <div className="mt-10 flex justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-surface-border border-t-accent-400" />
          </div>
        ) : (
          <>
            {/* Voting control */}
            <Section title="Voting control">
              <div className="rounded-2xl border border-surface-border bg-surface p-5">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-medium text-ash-100">
                      Week {WEEKS.VOTING} voting window
                    </p>
                    {window_ ? (
                      <CountdownTimer
                        closesAt={window_.closes_at}
                        isOpen={window_.is_open}
                      />
                    ) : (
                      <p className="text-sm text-ash-400">
                        No voting window configured.
                      </p>
                    )}
                  </div>
                  <span
                    className={`rounded-full px-3 py-1 text-xs font-semibold ${
                      window_?.is_open
                        ? "bg-accent-400/10 text-accent-400"
                        : "bg-coral-400/10 text-coral-400"
                    }`}
                  >
                    {window_?.is_open ? "Open" : "Closed"}
                  </span>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => updateWindow({ is_open: !window_?.is_open })}
                    disabled={windowBusy || !window_}
                    className="inline-flex items-center gap-2 rounded-xl border border-surface-border px-3 py-2 text-sm font-medium text-ash-300 transition-colors hover:border-accent-400/40 hover:text-accent-400 disabled:opacity-50"
                  >
                    {window_?.is_open ? (
                      <PauseCircle size={16} />
                    ) : (
                      <PlayCircle size={16} />
                    )}
                    {window_?.is_open ? "Close voting" : "Reopen voting"}
                  </button>
                  <button
                    onClick={() => extendByHours(6)}
                    disabled={windowBusy || !window_}
                    className="inline-flex items-center gap-2 rounded-xl border border-surface-border px-3 py-2 text-sm font-medium text-ash-300 transition-colors hover:border-accent-400/40 hover:text-accent-400 disabled:opacity-50"
                  >
                    <Clock4 size={16} />
                    Extend by 6h
                  </button>
                  <button
                    onClick={() => updateWindow({ is_published: !window_?.is_published })}
                    disabled={windowBusy || !window_}
                    className="inline-flex items-center gap-2 rounded-xl border border-surface-border px-3 py-2 text-sm font-medium text-ash-300 transition-colors hover:border-accent-400/40 hover:text-accent-400 disabled:opacity-50"
                  >
                    <Megaphone size={16} />
                    {window_?.is_published
                      ? "Unpublish menu"
                      : "Publish final menu"}
                  </button>
                </div>
                {window_?.is_published && (
                  <p className="mt-3 text-xs text-accent-400">
                    Students have been notified that next week's menu is
                    published.
                  </p>
                )}
              </div>
            </Section>

            <Section title={`Currently serving — week ${WEEKS.SERVED}`}>
              {served.map((item) => (
                <MenuRow
                  key={item.id}
                  item={item}
                  onToggleLock={toggleLock}
                  onDelete={remove}
                />
              ))}
            </Section>

            <Section title={`Voting now — week ${WEEKS.VOTING}`}>
              {voting.map((item) => (
                <MenuRow
                  key={item.id}
                  item={item}
                  onToggleLock={toggleLock}
                  onDelete={remove}
                />
              ))}
            </Section>

            <Section title="Add a new dish">
              <form
                onSubmit={handleSubmit}
                className="grid grid-cols-1 gap-3 sm:grid-cols-2"
              >
                <input
                  required
                  placeholder="Dish name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="rounded-xl border border-surface-border bg-surface px-4 py-2.5 text-sm text-ash-100 placeholder:text-ash-500 focus:border-accent-400 sm:col-span-2"
                />
                <input
                  placeholder="Short description"
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                  className="rounded-xl border border-surface-border bg-surface px-4 py-2.5 text-sm text-ash-100 placeholder:text-ash-500 focus:border-accent-400 sm:col-span-2"
                />
                <select
                  value={form.category}
                  disabled={form.is_staple}
                  onChange={(e) =>
                    setForm({ ...form, category: e.target.value })
                  }
                  className="rounded-xl border border-surface-border bg-surface px-4 py-2.5 text-sm text-ash-100 focus:border-accent-400 disabled:opacity-50"
                >
                  {VOTE_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <select
                  value={form.dietary_tag}
                  onChange={(e) =>
                    setForm({ ...form, dietary_tag: e.target.value })
                  }
                  className="rounded-xl border border-surface-border bg-surface px-4 py-2.5 text-sm text-ash-100 focus:border-accent-400"
                >
                  {DIET_TAGS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-ash-500">
                    Relative plate cost
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={form.cost_weight}
                    onChange={(e) =>
                      setForm({ ...form, cost_weight: e.target.value })
                    }
                    className="rounded-xl border border-surface-border bg-surface px-4 py-2.5 text-sm text-ash-100 focus:border-accent-400"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-ash-500">Week</label>
                  <select
                    value={form.week}
                    onChange={(e) => setForm({ ...form, week: e.target.value })}
                    className="rounded-xl border border-surface-border bg-surface px-4 py-2.5 text-sm text-ash-100 focus:border-accent-400"
                  >
                    <option value={WEEKS.SERVED}>
                      Week {WEEKS.SERVED} (serving now)
                    </option>
                    <option value={WEEKS.VOTING}>
                      Week {WEEKS.VOTING} (voting)
                    </option>
                  </select>
                </div>
                <label className="flex items-center gap-2 text-sm text-ash-300 sm:col-span-2">
                  <input
                    type="checkbox"
                    checked={form.is_staple}
                    onChange={(e) =>
                      setForm({ ...form, is_staple: e.target.checked })
                    }
                    className="h-4 w-4 rounded border-surface-border accent-accent-400"
                  />
                  Daily staple (always available, not part of voting)
                </label>
                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-accent-400 px-4 py-2.5 text-sm font-semibold text-ink transition-colors hover:bg-accent-200 disabled:opacity-50 sm:col-span-2"
                >
                  <Plus size={16} />
                  {submitting ? "Adding…" : "Add dish"}
                </button>
              </form>
            </Section>
          </>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="mt-8">
      <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ash-500">
        {title}
      </h2>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function MenuRow({ item, onToggleLock, onDelete }) {
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-surface-border bg-surface p-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="font-display text-sm font-semibold text-ash-100">
          {item.name}
        </h3>
        <DietBadge tag={item.dietary_tag} />
        <span className="rounded-full bg-surface-raised px-2.5 py-1 text-xs font-medium text-ash-500">
          {item.is_staple ? "staple" : item.category}
        </span>
        <span className="rounded-full bg-surface-raised px-2.5 py-1 font-mono text-xs text-ash-500">
          cost {item.cost_weight.toFixed(1)}x
        </span>
      </div>
      <div className="flex items-center gap-2">
        {!item.is_staple && (
          <button
            onClick={() => onToggleLock(item)}
            className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
              item.is_locked
                ? "border-saffron-400/40 bg-saffron-400/10 text-saffron-400"
                : "border-surface-border text-ash-400 hover:text-ash-100"
            }`}
          >
            {item.is_locked ? <Lock size={13} /> : <Unlock size={13} />}
            {item.is_locked ? "Locked" : "Unlocked"}
          </button>
        )}
        <button
          onClick={() => onDelete(item)}
          className="flex items-center justify-center rounded-lg border border-surface-border p-1.5 text-ash-400 transition-colors hover:border-coral-400/40 hover:text-coral-400"
        >
          <Trash2 size={14} />
        </button>
      </div>
    </div>
  );
}

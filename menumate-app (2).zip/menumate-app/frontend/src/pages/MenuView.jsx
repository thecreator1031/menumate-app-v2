import { useEffect, useState } from "react";
import { CalendarCheck, Hourglass, Utensils } from "lucide-react";
import Navbar from "../components/Navbar";
import DietBadge from "../components/DietBadge";
import StaplesBanner from "../components/StaplesBanner";
import { api, WEEKS, VOTE_CATEGORIES } from "../api";

const CATEGORY_LABELS = {
  breakfast: "Breakfast",
  lunch: "Lunch",
  snacks: "Snacks",
  dinner: "Dinner",
  dessert: "Desserts",
};

export default function MenuView() {
  const [served, setServed] = useState([]);
  const [staples, setStaples] = useState([]);
  const [voting, setVoting] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([
      api.getMenu(WEEKS.SERVED, true),
      api.getVoteStatus("ADMIN1", WEEKS.VOTING).catch(() => null),
    ])
      .then(([servedMenu, votingStatus]) => {
        setServed(servedMenu.filter((i) => !i.is_staple));
        setStaples(servedMenu.filter((i) => i.is_staple));
        setVoting(votingStatus);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const grouped = served.reduce((acc, item) => {
    acc[item.category] = acc[item.category] || [];
    acc[item.category].push(item);
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex min-h-[60vh] items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-surface-border border-t-accent-400" />
        </div>
      </div>
    );
  }

  const published = voting?.window?.is_published;

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto max-w-5xl px-6 py-10">
        <h1 className="font-display text-3xl font-semibold text-ash-100">
          This week's menu
        </h1>
        <p className="mt-1 text-sm text-ash-400">
          Finalized dishes being served this week, based on last week's
          votes.
        </p>

        {error && (
          <p className="mt-4 rounded-lg border border-coral-400/30 bg-coral-400/10 px-3 py-2 text-sm text-coral-400">
            {error}
          </p>
        )}

        {published ? (
          <p className="mt-4 flex items-center gap-2 rounded-lg border border-accent-400/30 bg-accent-400/10 px-3 py-2 text-sm text-accent-400">
            <CalendarCheck size={16} />
            Next week's menu has been published — check back next cycle to
            see it served here.
          </p>
        ) : (
          <p className="mt-4 flex items-center gap-2 rounded-lg border border-surface-border bg-surface px-3 py-2 text-sm text-ash-400">
            <Hourglass size={16} />
            Next week's menu is still being decided by votes.
          </p>
        )}

        <div className="mt-6">
          <StaplesBanner staples={staples} />
        </div>

        <div className="mt-8 space-y-8">
          {VOTE_CATEGORIES.filter((cat) => grouped[cat]?.length).map((category) => (
            <div key={category}>
              <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ash-500">
                {CATEGORY_LABELS[category] || category}
              </h2>
              <div className="space-y-3">
                {grouped[category].map((item) => (
                  <div
                    key={item.id}
                    className="flex flex-wrap items-center gap-3 rounded-2xl border border-surface-border bg-surface p-4"
                  >
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-raised text-ash-500">
                      <Utensils size={16} />
                    </span>
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-display text-sm font-semibold text-ash-100">
                          {item.name}
                        </h3>
                        <DietBadge tag={item.dietary_tag} />
                      </div>
                      {item.description && (
                        <p className="mt-1 text-sm text-ash-400">
                          {item.description}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

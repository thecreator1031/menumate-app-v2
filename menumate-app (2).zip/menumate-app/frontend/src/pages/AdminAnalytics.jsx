import { useEffect, useState } from "react";
import {
  Line,
  LineChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  Trash2,
  Plus,
  Leaf,
  Star,
} from "lucide-react";
import Navbar from "../components/Navbar";
import DietBadge from "../components/DietBadge";
import { api } from "../api";

const emptyWasteForm = { menu_item_id: "", quantity_kg: "", notes: "" };

export default function AdminAnalytics() {
  const [preferences, setPreferences] = useState(null);
  const [sustainability, setSustainability] = useState(null);
  const [wasteLogs, setWasteLogs] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [form, setForm] = useState(emptyWasteForm);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const load = () => {
    Promise.all([
      api.preferenceReport(),
      api.sustainabilityReport(),
      api.adminListWaste(),
      api.getMenu(),
    ])
      .then(([pref, sus, waste, menu]) => {
        setPreferences(pref);
        setSustainability(sus);
        setWasteLogs(waste);
        setMenuItems(menu.filter((m) => !m.is_staple));
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const handleWasteSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      const created = await api.adminLogWaste({
        menu_item_id: form.menu_item_id ? Number(form.menu_item_id) : null,
        quantity_kg: Number(form.quantity_kg),
        notes: form.notes,
      });
      setWasteLogs((prev) => [created, ...prev]);
      setForm(emptyWasteForm);
      // Refresh sustainability report since waste totals changed
      api.sustainabilityReport().then(setSustainability).catch(() => {});
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const itemsById = Object.fromEntries(menuItems.map((m) => [m.id, m]));

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex min-h-[60vh] items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-surface-border border-t-accent-400" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="mx-auto max-w-5xl px-6 py-10">
        <h1 className="font-display text-3xl font-semibold text-ash-100">
          Analytics & sustainability
        </h1>
        <p className="mt-1 text-sm text-ash-400">
          Preference trends for grocery planning, plus waste vs. cost vs.
          satisfaction over time.
        </p>

        {error && (
          <p className="mt-4 rounded-lg border border-coral-400/30 bg-coral-400/10 px-3 py-2 text-sm text-coral-400">
            {error}
          </p>
        )}

        {/* Preference analytics */}
        <Section title="Preference analytics">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <RankedList
              title="Most popular dishes"
              icon={TrendingUp}
              accent="accent"
              items={preferences?.most_popular || []}
            />
            <RankedList
              title="Least popular dishes"
              icon={TrendingDown}
              accent="coral"
              items={preferences?.least_popular || []}
            />
          </div>
          <p className="mt-3 text-xs text-ash-500">
            Use this to guide grocery and prep-quantity planning for upcoming
            weeks.
          </p>
        </Section>

        {/* Sustainability report */}
        <Section title="Sustainability report">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <KpiCard
              icon={Leaf}
              label="Total waste logged"
              value={`${sustainability?.total_waste_kg ?? 0} kg`}
              accent="coral"
            />
            <KpiCard
              icon={Star}
              label="Avg. satisfaction"
              value={`${sustainability?.avg_satisfaction ?? 0} / 5`}
            />
            <KpiCard
              icon={TrendingUp}
              label="Avg. cost index"
              value={`${sustainability?.avg_cost_index ?? 0}x`}
              accent="saffron"
            />
          </div>

          <div className="mt-4 h-72 rounded-2xl border border-surface-border bg-surface p-5">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sustainability?.points || []} margin={{ left: -10, right: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2B2B27" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: "#A3A39E", fontSize: 11 }}
                  axisLine={{ stroke: "#2B2B27" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "#A3A39E", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    background: "#1C1C19",
                    border: "1px solid #2B2B27",
                    borderRadius: "0.75rem",
                    fontSize: "0.8rem",
                  }}
                  labelStyle={{ color: "#F5F5F4" }}
                />
                <Legend wrapperStyle={{ fontSize: "0.75rem" }} />
                <Line type="monotone" dataKey="waste_kg" name="Waste (kg)" stroke="#FB7185" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="cost_index" name="Cost index" stroke="#FBBF24" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="satisfaction" name="Satisfaction" stroke="#34D399" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Section>

        {/* Waste tracking */}
        <Section title="Waste tracking">
          <form
            onSubmit={handleWasteSubmit}
            className="grid grid-cols-1 gap-3 rounded-2xl border border-surface-border bg-surface p-5 sm:grid-cols-2"
          >
            <select
              value={form.menu_item_id}
              onChange={(e) => setForm({ ...form, menu_item_id: e.target.value })}
              className="rounded-xl border border-surface-border bg-surface-raised px-4 py-2.5 text-sm text-ash-100 focus:border-accent-400 sm:col-span-2"
            >
              <option value="">General / unspecified dish</option>
              {menuItems.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} (week {m.week})
                </option>
              ))}
            </select>
            <input
              required
              type="number"
              step="0.1"
              min="0"
              placeholder="Quantity wasted (kg)"
              value={form.quantity_kg}
              onChange={(e) => setForm({ ...form, quantity_kg: e.target.value })}
              className="rounded-xl border border-surface-border bg-surface-raised px-4 py-2.5 text-sm text-ash-100 placeholder:text-ash-500 focus:border-accent-400"
            />
            <input
              placeholder="Notes (optional)"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className="rounded-xl border border-surface-border bg-surface-raised px-4 py-2.5 text-sm text-ash-100 placeholder:text-ash-500 focus:border-accent-400"
            />
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-accent-400 px-4 py-2.5 text-sm font-semibold text-ink transition-colors hover:bg-accent-200 disabled:opacity-50 sm:col-span-2"
            >
              <Plus size={16} />
              {submitting ? "Logging…" : "Log waste entry"}
            </button>
          </form>

          <div className="mt-4 space-y-2">
            {wasteLogs.slice(0, 8).map((log) => (
              <div
                key={log.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-surface-border bg-surface p-4"
              >
                <div className="flex items-center gap-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-coral-400/10 text-coral-400">
                    <Trash2 size={14} />
                  </span>
                  <div>
                    <p className="text-sm font-medium text-ash-100">
                      {log.menu_item_id && itemsById[log.menu_item_id]
                        ? itemsById[log.menu_item_id].name
                        : "General waste"}
                    </p>
                    <p className="text-xs text-ash-500">
                      {log.date} · {log.notes || "No notes"}
                    </p>
                  </div>
                </div>
                <span className="font-mono text-sm text-ash-300">
                  {log.quantity_kg} kg
                </span>
              </div>
            ))}
            {wasteLogs.length === 0 && (
              <p className="text-sm text-ash-400">No waste logged yet.</p>
            )}
          </div>
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="mt-8">
      <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ash-500">
        {title}
      </h2>
      {children}
    </div>
  );
}

function RankedList({ title, icon: Icon, accent, items }) {
  const accentClasses = {
    accent: "bg-accent-400/10 text-accent-400",
    coral: "bg-coral-400/10 text-coral-400",
  };
  return (
    <div className="rounded-2xl border border-surface-border bg-surface p-5">
      <div className="flex items-center gap-2">
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${accentClasses[accent]}`}>
          <Icon size={14} />
        </span>
        <h3 className="font-display text-sm font-semibold text-ash-100">{title}</h3>
      </div>
      <div className="mt-3 space-y-2">
        {items.length === 0 && (
          <p className="text-sm text-ash-400">Not enough data yet.</p>
        )}
        {items.map((item, idx) => (
          <div
            key={item.id}
            className="flex items-center justify-between gap-2 rounded-xl border border-surface-border bg-surface-raised px-3 py-2"
          >
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs text-ash-500">#{idx + 1}</span>
              <span className="text-sm font-medium text-ash-100">{item.name}</span>
              <DietBadge tag={item.dietary_tag} />
            </div>
            <div className="flex items-center gap-3 font-mono text-xs text-ash-400">
              <span>{item.total_votes} votes</span>
              {item.avg_rating != null && <span>★ {item.avg_rating}</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function KpiCard({ icon: Icon, label, value, accent = "accent" }) {
  const accentClasses = {
    accent: "bg-accent-400/10 text-accent-400",
    coral: "bg-coral-400/10 text-coral-400",
    saffron: "bg-saffron-400/10 text-saffron-400",
  };
  return (
    <div className="rounded-2xl border border-surface-border bg-surface p-5">
      <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${accentClasses[accent]}`}>
        <Icon size={18} />
      </span>
      <p className="mt-3 font-display text-2xl font-semibold text-ash-100">{value}</p>
      <p className="text-sm font-medium text-ash-300">{label}</p>
    </div>
  );
}

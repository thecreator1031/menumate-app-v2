from datetime import timedelta

from sqlalchemy.orm import Session

from config import (
    CURRENT_WEEK,
    VOTING_WEEK,
    TODAY,
    DAILY_STAPLES,
    VOTING_OPENS_AT,
    VOTING_CLOSES_AT,
)
from models import Student, MenuItem, Vote, CheckIn, VotingWindow, WasteLog


def seed_data(db: Session) -> None:
    """Populate the database with demo data if it's empty."""
    if db.query(Student).first():
        return  # already seeded

    # ---------------- Students ----------------
    students = [
        Student(id="S1001", name="Aanya Sharma", role="student", dietary_pref="veg"),
        Student(id="S1002", name="Rohan Mehta", role="student", dietary_pref="non_veg"),
        Student(id="S1003", name="Kabir Singh", role="student", dietary_pref="jain"),
        Student(id="S1004", name="Priya Nair", role="student", dietary_pref="veg"),
        Student(id="S1005", name="Arjun Rao", role="student", dietary_pref="non_veg"),
        Student(id="S1006", name="Diya Patel", role="student", dietary_pref="jain"),
        Student(id="ADMIN1", name="Mess Admin", role="admin", dietary_pref="veg"),
    ]
    db.add_all(students)
    db.commit()

    # ---------------- Daily staples (always available, every week) ----------------
    staple_items = [
        MenuItem(
            name=s["name"],
            description=s["description"],
            category="staple",
            dietary_tag=s["dietary_tag"],
            cost_weight=0.4,
            week=CURRENT_WEEK,
            status="served",
            is_locked=False,
            is_staple=True,
        )
        for s in DAILY_STAPLES
    ]
    db.add_all(staple_items)
    db.commit()

    # ---------------- Week 1 (being served) ----------------
    served_items = [
        MenuItem(name="Paneer Butter Masala", description="Creamy tomato paneer curry", category="lunch", dietary_tag="veg", cost_weight=1.2, week=CURRENT_WEEK, status="served", is_locked=True),
        MenuItem(name="Chicken Curry", description="Classic spiced chicken curry", category="lunch", dietary_tag="non_veg", cost_weight=1.8, week=CURRENT_WEEK, status="served", is_locked=False),
        MenuItem(name="Veg Pulao", description="Fragrant rice with mixed vegetables", category="dinner", dietary_tag="jain", cost_weight=1.0, week=CURRENT_WEEK, status="served", is_locked=False),
        MenuItem(name="Egg Curry", description="Boiled eggs in a spiced gravy", category="dinner", dietary_tag="non_veg", cost_weight=1.3, week=CURRENT_WEEK, status="served", is_locked=False),
        MenuItem(name="Masala Khichdi", description="Comfort rice and lentil porridge", category="breakfast", dietary_tag="jain", cost_weight=0.6, week=CURRENT_WEEK, status="served", is_locked=False),
        MenuItem(name="Veg Sandwich", description="Grilled bread with veggies and chutney", category="snacks", dietary_tag="veg", cost_weight=0.7, week=CURRENT_WEEK, status="served", is_locked=False),
        MenuItem(name="Gulab Jamun", description="Soft milk-solid dumplings in sugar syrup", category="dessert", dietary_tag="veg", cost_weight=0.8, week=CURRENT_WEEK, status="served", is_locked=False),
    ]
    db.add_all(served_items)
    db.commit()

    # ---------------- Week 2 (voting now) ----------------
    candidate_items = [
        MenuItem(name="Rajma Chawal", description="Kidney bean curry with steamed rice", category="lunch", dietary_tag="veg", cost_weight=1.0, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Mutton Curry", description="Slow-cooked mutton in rich masala", category="lunch", dietary_tag="non_veg", cost_weight=2.2, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Jain Pulao", description="No onion-garlic vegetable pulao", category="lunch", dietary_tag="jain", cost_weight=0.9, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Aloo Gobi", description="Potato and cauliflower stir-fry", category="lunch", dietary_tag="jain", cost_weight=0.7, week=VOTING_WEEK, status="candidate", is_locked=True),
        MenuItem(name="Masala Dosa", description="Crisp rice crepe with potato filling", category="breakfast", dietary_tag="veg", cost_weight=0.9, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Poha", description="Flattened rice tempered with peanuts and curry leaves", category="breakfast", dietary_tag="jain", cost_weight=0.5, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Samosa Chaat", description="Crushed samosas with chutneys and yogurt", category="snacks", dietary_tag="veg", cost_weight=0.8, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Corn Chaat", description="Tangy spiced sweet corn salad", category="snacks", dietary_tag="jain", cost_weight=0.6, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Fish Curry", description="Coastal-style fish in coconut gravy", category="dinner", dietary_tag="non_veg", cost_weight=1.9, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Paneer Tikka", description="Char-grilled marinated paneer skewers", category="dinner", dietary_tag="veg", cost_weight=1.4, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Gajar Halwa", description="Sweet carrot pudding with nuts and ghee", category="dessert", dietary_tag="veg", cost_weight=0.9, week=VOTING_WEEK, status="candidate", is_locked=False),
        MenuItem(name="Fruit Custard", description="Chilled custard with seasonal fruit", category="dessert", dietary_tag="jain", cost_weight=0.7, week=VOTING_WEEK, status="candidate", is_locked=False),
    ]
    db.add_all(candidate_items)
    db.commit()

    # Daily staples are also available in week 2
    staple_items_w2 = [
        MenuItem(
            name=s["name"],
            description=s["description"],
            category="staple",
            dietary_tag=s["dietary_tag"],
            cost_weight=0.4,
            week=VOTING_WEEK,
            status="candidate",
            is_locked=False,
            is_staple=True,
        )
        for s in DAILY_STAPLES
    ]
    db.add_all(staple_items_w2)
    db.commit()

    # ---------------- Voting window for week 2 ----------------
    db.add(
        VotingWindow(
            week=VOTING_WEEK,
            opens_at=VOTING_OPENS_AT,
            closes_at=VOTING_CLOSES_AT,
            is_open=True,
            is_published=False,
        )
    )
    db.add(
        VotingWindow(
            week=CURRENT_WEEK,
            opens_at=VOTING_OPENS_AT - timedelta(days=7),
            closes_at=VOTING_CLOSES_AT - timedelta(days=7),
            is_open=False,
            is_published=True,
        )
    )
    db.commit()

    # ---------------- Seed likes/votes for week 2 (from S1001-S1006) ----------------
    candidates_by_name = {item.name: item for item in candidate_items}

    seed_votes = [
        ("S1001", "Masala Dosa"),
        ("S1001", "Jain Pulao"),
        ("S1001", "Gajar Halwa"),
        ("S1001", "Corn Chaat"),
        ("S1002", "Mutton Curry"),
        ("S1002", "Fish Curry"),
        ("S1002", "Rajma Chawal"),
        ("S1002", "Masala Dosa"),
        ("S1002", "Gajar Halwa"),
        ("S1003", "Jain Pulao"),
        ("S1003", "Aloo Gobi"),
        ("S1003", "Masala Dosa"),
        ("S1003", "Fruit Custard"),
        ("S1003", "Poha"),
        ("S1004", "Rajma Chawal"),
        ("S1004", "Paneer Tikka"),
        ("S1004", "Masala Dosa"),
        ("S1004", "Samosa Chaat"),
        ("S1005", "Mutton Curry"),
        ("S1005", "Fish Curry"),
        ("S1005", "Rajma Chawal"),
        ("S1005", "Paneer Tikka"),
        ("S1006", "Jain Pulao"),
        ("S1006", "Aloo Gobi"),
        ("S1006", "Masala Dosa"),
        ("S1006", "Fruit Custard"),
    ]
    for student_id, item_name in seed_votes:
        db.add(Vote(student_id=student_id, menu_item_id=candidates_by_name[item_name].id, week=VOTING_WEEK))
    db.commit()

    # ---------------- Seed check-ins, ratings & feedback for week 1 ----------------
    served_by_name = {item.name: item for item in served_items}

    # Each tuple: (student_id, item_name, days_ago, rating, waste_flag, feedback)
    seed_checkins = [
        ("S1001", "Paneer Butter Masala", 1, 5, False, "Loved the creaminess, please keep this!"),
        ("S1001", "Gulab Jamun", 0, 5, False, None),
        ("S1002", "Chicken Curry", 1, 5, False, None),
        ("S1002", "Egg Curry", 0, 3, True, "A bit too spicy for me, lots left on the plate"),
        ("S1003", "Veg Pulao", 1, 4, False, None),
        ("S1003", "Masala Khichdi", 0, 4, False, "Good comfort food, maybe add more veggies"),
        ("S1004", "Paneer Butter Masala", 1, 5, False, None),
        ("S1004", "Veg Sandwich", 0, 2, True, "Bread was a bit stale today"),
        ("S1005", "Chicken Curry", 1, 5, False, None),
        ("S1005", "Egg Curry", 0, 4, False, None),
        ("S1006", "Veg Pulao", 1, 3, True, None),
        ("S1006", "Masala Khichdi", 0, 5, False, None),
        ("S1002", "Paneer Butter Masala", 1, 4, False, None),
        ("S1004", "Chicken Curry", 1, 3, False, None),
        ("S1003", "Gulab Jamun", 0, 5, False, "More of these please!"),
    ]
    for student_id, item_name, days_ago, rating, waste_flag, feedback in seed_checkins:
        db.add(
            CheckIn(
                student_id=student_id,
                menu_item_id=served_by_name[item_name].id,
                date=TODAY - timedelta(days=days_ago),
                rating=rating,
                waste_flag=waste_flag,
                feedback=feedback,
            )
        )
    db.commit()

    # ---------------- Seed waste logs for week 1 ----------------
    seed_waste = [
        ("Paneer Butter Masala", 1, 1.2, "A bit of leftover from dinner batch"),
        ("Chicken Curry", 1, 0.8, ""),
        ("Veg Pulao", 1, 2.5, "Overcooked batch, low turnout"),
        ("Egg Curry", 0, 1.5, "Several plates returned with leftovers"),
        ("Masala Khichdi", 0, 0.6, ""),
        ("Veg Sandwich", 0, 1.0, "Bread quality complaints, low uptake"),
        ("Gulab Jamun", 0, 0.3, ""),
    ]
    for item_name, days_ago, qty, notes in seed_waste:
        db.add(
            WasteLog(
                menu_item_id=served_by_name[item_name].id,
                date=TODAY - timedelta(days=days_ago),
                quantity_kg=qty,
                notes=notes,
            )
        )
    db.commit()

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship

from database import Base


class Student(Base):
    __tablename__ = "students"

    id = Column(String, primary_key=True)  # e.g. "S1001" or "ADMIN1"
    name = Column(String, nullable=False)
    role = Column(String, default="student")  # "student" | "admin"
    dietary_pref = Column(String, default="veg")  # veg | non_veg | jain

    votes = relationship("Vote", back_populates="student")
    checkins = relationship("CheckIn", back_populates="student")


class MenuItem(Base):
    __tablename__ = "menu_items"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    description = Column(String, default="")
    category = Column(String, default="lunch")  # breakfast | lunch | snacks | dinner | dessert | staple
    dietary_tag = Column(String, default="veg")  # veg | non_veg | jain
    cost_weight = Column(Float, default=1.0)  # relative plate cost
    week = Column(Integer, nullable=False)  # which week this item belongs to
    status = Column(String, default="candidate")  # candidate | finalized | served
    is_locked = Column(Boolean, default=False)  # rotation lock (crowd favorite, guaranteed a spot)
    is_staple = Column(Boolean, default=False)  # always-available daily staple (not voted on)
    image_url = Column(String, nullable=True)  # optional dish photo

    votes = relationship("Vote", back_populates="menu_item")
    checkins = relationship("CheckIn", back_populates="menu_item")


class Vote(Base):
    """A single student's 'like' vote for a dish in a given week.

    One row per (student, menu_item, week) — toggled on/off, no point weighting.
    """

    __tablename__ = "votes"
    __table_args__ = (
        UniqueConstraint("student_id", "menu_item_id", "week", name="uq_vote_student_item_week"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    student_id = Column(String, ForeignKey("students.id"), nullable=False)
    menu_item_id = Column(Integer, ForeignKey("menu_items.id"), nullable=False)
    week = Column(Integer, nullable=False)

    student = relationship("Student", back_populates="votes")
    menu_item = relationship("MenuItem", back_populates="votes")


class CheckIn(Base):
    __tablename__ = "checkins"

    id = Column(Integer, primary_key=True, autoincrement=True)
    student_id = Column(String, ForeignKey("students.id"), nullable=False)
    menu_item_id = Column(Integer, ForeignKey("menu_items.id"), nullable=False)
    date = Column(Date, nullable=False)
    rating = Column(Integer, nullable=True)  # 1-5
    waste_flag = Column(Boolean, default=False)
    feedback = Column(String, nullable=True)  # free-text feedback / suggestions

    student = relationship("Student", back_populates="checkins")
    menu_item = relationship("MenuItem", back_populates="checkins")


class VotingWindow(Base):
    """Controls when voting opens/closes for a given week, and publication state."""

    __tablename__ = "voting_windows"

    week = Column(Integer, primary_key=True)
    opens_at = Column(DateTime, nullable=False)
    closes_at = Column(DateTime, nullable=False)
    is_open = Column(Boolean, default=True)
    is_published = Column(Boolean, default=False)  # final menu has been published to students


class WasteLog(Base):
    """Daily food-waste entries logged by admins (kg or portions of leftovers)."""

    __tablename__ = "waste_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    menu_item_id = Column(Integer, ForeignKey("menu_items.id"), nullable=True)
    date = Column(Date, nullable=False)
    quantity_kg = Column(Float, nullable=False)
    notes = Column(String, default="")

    menu_item = relationship("MenuItem")

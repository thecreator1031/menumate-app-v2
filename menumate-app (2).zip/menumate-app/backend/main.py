from datetime import date, datetime, timedelta
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func
from sqlalchemy.orm import Session

import models
import schemas
from config import CURRENT_WEEK, VOTING_WEEK, TODAY
from database import Base, SessionLocal, engine, get_db
from seed import seed_data

Base.metadata.create_all(bind=engine)

with SessionLocal() as db:
    seed_data(db)

app = FastAPI(title="MenuMate API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def health():
    return {"status": "ok", "service": "menumate-api"}


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
@app.post("/api/auth/login", response_model=schemas.StudentOut)
def login(payload: schemas.LoginRequest, db: Session = Depends(get_db)):
    student = db.get(models.Student, payload.student_id.strip().upper())
    if not student:
        raise HTTPException(status_code=404, detail="Unknown ID. Try S1001-S1006 or ADMIN1.")
    return student


# ---------------------------------------------------------------------------
# Menu
# ---------------------------------------------------------------------------
@app.get("/api/menu", response_model=List[schemas.MenuItemOut])
def get_menu(week: Optional[int] = None, include_staples: bool = True, db: Session = Depends(get_db)):
    query = db.query(models.MenuItem)
    if week is not None:
        query = query.filter(models.MenuItem.week == week)
    if not include_staples:
        query = query.filter(models.MenuItem.is_staple.is_(False))
    return query.order_by(models.MenuItem.category, models.MenuItem.name).all()


# ---------------------------------------------------------------------------
# Voting (simple like/toggle, no token budget)
# ---------------------------------------------------------------------------
def _get_or_default_window(db: Session, week: int) -> Optional[models.VotingWindow]:
    return db.get(models.VotingWindow, week)


def _build_vote_status(db: Session, student: models.Student, week: int) -> schemas.VoteStatusOut:
    items = (
        db.query(models.MenuItem)
        .filter(models.MenuItem.week == week, models.MenuItem.is_staple.is_(False))
        .order_by(models.MenuItem.category, models.MenuItem.name)
        .all()
    )
    staples = (
        db.query(models.MenuItem)
        .filter(models.MenuItem.week == week, models.MenuItem.is_staple.is_(True))
        .order_by(models.MenuItem.name)
        .all()
    )

    totals = dict(
        db.query(models.Vote.menu_item_id, func.count(models.Vote.id))
        .filter(models.Vote.week == week)
        .group_by(models.Vote.menu_item_id)
        .all()
    )

    mine = {
        mid
        for (mid,) in db.query(models.Vote.menu_item_id)
        .filter(models.Vote.week == week, models.Vote.student_id == student.id)
        .all()
    }

    out_items = [
        schemas.MenuItemWithVotes(
            id=item.id,
            name=item.name,
            description=item.description,
            category=item.category,
            dietary_tag=item.dietary_tag,
            cost_weight=item.cost_weight,
            week=item.week,
            status=item.status,
            is_locked=item.is_locked,
            is_staple=item.is_staple,
            image_url=item.image_url,
            total_votes=int(totals.get(item.id, 0)),
            voted_by_me=item.id in mine,
        )
        for item in items
    ]

    window = _get_or_default_window(db, week)
    window_out = schemas.VotingWindowOut.model_validate(window) if window else None

    return schemas.VoteStatusOut(
        week=week,
        window=window_out,
        items=out_items,
        staples=staples,
    )


@app.get("/api/votes/{student_id}", response_model=schemas.VoteStatusOut)
def get_vote_status(student_id: str, week: int = VOTING_WEEK, db: Session = Depends(get_db)):
    student = db.get(models.Student, student_id.upper())
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    return _build_vote_status(db, student, week)


@app.post("/api/votes/toggle", response_model=schemas.VoteStatusOut)
def toggle_vote(payload: schemas.VoteToggleRequest, db: Session = Depends(get_db)):
    student = db.get(models.Student, payload.student_id.upper())
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    item = db.get(models.MenuItem, payload.menu_item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")

    if item.is_staple:
        raise HTTPException(status_code=400, detail="Daily staples aren't part of the vote")

    if item.is_locked:
        raise HTTPException(
            status_code=400,
            detail="This dish is rotation-locked (already a confirmed crowd favorite) and can't receive new votes.",
        )

    window = _get_or_default_window(db, payload.week)
    if window and not window.is_open:
        raise HTTPException(status_code=400, detail="Voting is closed for this week.")

    existing = (
        db.query(models.Vote)
        .filter(
            models.Vote.student_id == student.id,
            models.Vote.menu_item_id == payload.menu_item_id,
            models.Vote.week == payload.week,
        )
        .first()
    )

    if existing:
        db.delete(existing)
    else:
        db.add(
            models.Vote(
                student_id=student.id,
                menu_item_id=payload.menu_item_id,
                week=payload.week,
            )
        )
    db.commit()

    return _build_vote_status(db, student, payload.week)


# ---------------------------------------------------------------------------
# Notifications (derived from voting window state)
# ---------------------------------------------------------------------------
@app.get("/api/notifications/{student_id}", response_model=List[schemas.NotificationOut])
def get_notifications(student_id: str, db: Session = Depends(get_db)):
    student = db.get(models.Student, student_id.upper())
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    notifications: List[schemas.NotificationOut] = []
    now = datetime.now()

    windows = db.query(models.VotingWindow).order_by(models.VotingWindow.week.desc()).all()
    for w in windows:
        if w.is_published:
            notifications.append(
                schemas.NotificationOut(
                    id=f"published-{w.week}",
                    title=f"Week {w.week} menu published",
                    body="The final menu for next week has been published. Check the Menu tab!",
                    created_at=w.closes_at,
                    kind="menu_published",
                )
            )
        elif w.is_open:
            time_left = w.closes_at - now
            if time_left <= timedelta(hours=12) and time_left.total_seconds() > 0:
                notifications.append(
                    schemas.NotificationOut(
                        id=f"closing-{w.week}",
                        title=f"Voting for week {w.week} closes soon",
                        body=f"Less than {max(1, int(time_left.total_seconds() // 3600))} hour(s) left to vote — cast your votes now!",
                        created_at=now,
                        kind="voting_closing",
                    )
                )
            notifications.append(
                schemas.NotificationOut(
                    id=f"open-{w.week}",
                    title=f"Voting is open for week {w.week}",
                    body="Vote on your favorite dishes for next week's menu.",
                    created_at=w.opens_at,
                    kind="voting_open",
                )
            )

    notifications.sort(key=lambda n: n.created_at, reverse=True)
    return notifications


# ---------------------------------------------------------------------------
# Check-in & ratings & feedback
# ---------------------------------------------------------------------------
@app.post("/api/checkin", response_model=schemas.CheckInOut)
def check_in(payload: schemas.CheckInRequest, db: Session = Depends(get_db)):
    student = db.get(models.Student, payload.student_id.upper())
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    item = db.get(models.MenuItem, payload.menu_item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")

    checkin_date = payload.checkin_date or TODAY

    existing = (
        db.query(models.CheckIn)
        .filter(
            models.CheckIn.student_id == student.id,
            models.CheckIn.menu_item_id == item.id,
            models.CheckIn.date == checkin_date,
        )
        .first()
    )
    if existing:
        return existing

    record = models.CheckIn(
        student_id=student.id,
        menu_item_id=item.id,
        date=checkin_date,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@app.get("/api/checkins/{student_id}", response_model=List[schemas.CheckInOut])
def get_checkins(student_id: str, checkin_date: Optional[date] = None, db: Session = Depends(get_db)):
    query = db.query(models.CheckIn).filter(models.CheckIn.student_id == student_id.upper())
    if checkin_date is not None:
        query = query.filter(models.CheckIn.date == checkin_date)
    else:
        query = query.filter(models.CheckIn.date == TODAY)
    return query.all()


@app.post("/api/rate", response_model=schemas.CheckInOut)
def rate_meal(payload: schemas.RatingRequest, db: Session = Depends(get_db)):
    student = db.get(models.Student, payload.student_id.upper())
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")

    if not (1 <= payload.rating <= 5):
        raise HTTPException(status_code=400, detail="Rating must be between 1 and 5")

    checkin_date = payload.checkin_date or TODAY

    record = (
        db.query(models.CheckIn)
        .filter(
            models.CheckIn.student_id == student.id,
            models.CheckIn.menu_item_id == payload.menu_item_id,
            models.CheckIn.date == checkin_date,
        )
        .first()
    )
    if not record:
        record = models.CheckIn(
            student_id=student.id,
            menu_item_id=payload.menu_item_id,
            date=checkin_date,
        )
        db.add(record)

    record.rating = payload.rating
    record.waste_flag = payload.waste_flag
    if payload.feedback is not None:
        record.feedback = payload.feedback
    db.commit()
    db.refresh(record)
    return record


# ---------------------------------------------------------------------------
# Admin: menu management
# ---------------------------------------------------------------------------
@app.post("/api/admin/menu", response_model=schemas.MenuItemOut)
def create_menu_item(payload: schemas.MenuItemCreate, db: Session = Depends(get_db)):
    item = models.MenuItem(**payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@app.patch("/api/admin/menu/{item_id}", response_model=schemas.MenuItemOut)
def update_menu_item(item_id: int, payload: schemas.MenuItemUpdate, db: Session = Depends(get_db)):
    item = db.get(models.MenuItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")

    data = payload.model_dump(exclude_unset=True)
    for field, value in data.items():
        setattr(item, field, value)

    db.commit()
    db.refresh(item)
    return item


@app.delete("/api/admin/menu/{item_id}")
def delete_menu_item(item_id: int, db: Session = Depends(get_db)):
    item = db.get(models.MenuItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")
    db.delete(item)
    db.commit()
    return {"deleted": item_id}


# ---------------------------------------------------------------------------
# Admin: voting control
# ---------------------------------------------------------------------------
@app.get("/api/admin/voting-window", response_model=schemas.VotingWindowOut)
def get_voting_window(week: int = VOTING_WEEK, db: Session = Depends(get_db)):
    window = db.get(models.VotingWindow, week)
    if not window:
        raise HTTPException(status_code=404, detail="No voting window configured for this week")
    return window


@app.patch("/api/admin/voting-window", response_model=schemas.VotingWindowOut)
def update_voting_window(payload: schemas.VotingWindowUpdate, week: int = VOTING_WEEK, db: Session = Depends(get_db)):
    window = db.get(models.VotingWindow, week)
    if not window:
        raise HTTPException(status_code=404, detail="No voting window configured for this week")

    if payload.is_open is not None:
        window.is_open = payload.is_open
    if payload.is_published is not None:
        window.is_published = payload.is_published
    if payload.closes_at is not None:
        window.closes_at = payload.closes_at

    db.commit()
    db.refresh(window)
    return window


# ---------------------------------------------------------------------------
# Admin: waste tracking
# ---------------------------------------------------------------------------
@app.post("/api/admin/waste", response_model=schemas.WasteLogOut)
def log_waste(payload: schemas.WasteLogCreate, db: Session = Depends(get_db)):
    if payload.menu_item_id is not None and not db.get(models.MenuItem, payload.menu_item_id):
        raise HTTPException(status_code=404, detail="Menu item not found")

    record = models.WasteLog(
        menu_item_id=payload.menu_item_id,
        date=payload.date or TODAY,
        quantity_kg=payload.quantity_kg,
        notes=payload.notes,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@app.get("/api/admin/waste", response_model=List[schemas.WasteLogOut])
def list_waste(db: Session = Depends(get_db)):
    return db.query(models.WasteLog).order_by(models.WasteLog.date.desc()).all()


# ---------------------------------------------------------------------------
# Admin: dashboard
# ---------------------------------------------------------------------------
@app.get("/api/admin/dashboard", response_model=schemas.DashboardOut)
def dashboard(
    current_week: int = CURRENT_WEEK,
    voting_week: int = VOTING_WEEK,
    db: Session = Depends(get_db),
):
    total_students = (
        db.query(func.count(models.Student.id))
        .filter(models.Student.role == "student")
        .scalar()
        or 0
    )

    served_item_ids = [
        mid
        for (mid,) in db.query(models.MenuItem.id)
        .filter(models.MenuItem.week == current_week)
        .all()
    ]

    checkins = (
        db.query(models.CheckIn)
        .filter(models.CheckIn.menu_item_id.in_(served_item_ids))
        .all()
        if served_item_ids
        else []
    )

    total_checkins = len(checkins)
    unique_checked_in = len({c.student_id for c in checkins})
    turnout_pct = (unique_checked_in / total_students * 100) if total_students else 0.0

    wasted = sum(1 for c in checkins if c.waste_flag)
    waste_pct = (wasted / total_checkins * 100) if total_checkins else 0.0

    waste_kg_total = (
        db.query(func.coalesce(func.sum(models.WasteLog.quantity_kg), 0.0)).scalar() or 0.0
    )

    rated = [c.rating for c in checkins if c.rating is not None]
    satisfaction_index = (sum(rated) / len(rated)) if rated else 0.0

    items_by_id = {
        item.id: item
        for item in db.query(models.MenuItem).filter(models.MenuItem.week == current_week).all()
    }
    if checkins:
        cost_per_plate = sum(items_by_id[c.menu_item_id].cost_weight for c in checkins) / total_checkins
    else:
        cost_per_plate = 0.0

    # Vote summary for the voting week
    voting_items = (
        db.query(models.MenuItem)
        .filter(models.MenuItem.week == voting_week, models.MenuItem.is_staple.is_(False))
        .order_by(models.MenuItem.category, models.MenuItem.name)
        .all()
    )

    vote_totals = dict(
        db.query(models.Vote.menu_item_id, func.count(models.Vote.id))
        .filter(models.Vote.week == voting_week)
        .group_by(models.Vote.menu_item_id)
        .all()
    )

    vote_summary = [
        schemas.MenuVoteSummary(
            id=item.id,
            name=item.name,
            category=item.category,
            dietary_tag=item.dietary_tag,
            cost_weight=item.cost_weight,
            is_locked=item.is_locked,
            total_votes=int(vote_totals.get(item.id, 0)),
        )
        for item in voting_items
    ]

    window = db.get(models.VotingWindow, voting_week)
    window_out = schemas.VotingWindowOut.model_validate(window) if window else None

    return schemas.DashboardOut(
        current_week=current_week,
        voting_week=voting_week,
        total_students=total_students,
        turnout_pct=round(turnout_pct, 1),
        waste_pct=round(waste_pct, 1),
        waste_kg_total=round(waste_kg_total, 2),
        cost_per_plate=round(cost_per_plate, 2),
        satisfaction_index=round(satisfaction_index, 2),
        total_checkins=total_checkins,
        vote_summary=vote_summary,
        window=window_out,
    )


# ---------------------------------------------------------------------------
# Admin: analytics & sustainability reports
# ---------------------------------------------------------------------------
@app.get("/api/admin/reports/preferences", response_model=schemas.PreferenceReportOut)
def preference_report(db: Session = Depends(get_db)):
    items = (
        db.query(models.MenuItem)
        .filter(models.MenuItem.is_staple.is_(False))
        .all()
    )

    vote_totals = dict(
        db.query(models.Vote.menu_item_id, func.count(models.Vote.id))
        .group_by(models.Vote.menu_item_id)
        .all()
    )

    rating_avgs = dict(
        db.query(models.CheckIn.menu_item_id, func.avg(models.CheckIn.rating))
        .filter(models.CheckIn.rating.isnot(None))
        .group_by(models.CheckIn.menu_item_id)
        .all()
    )

    served_counts = dict(
        db.query(models.CheckIn.menu_item_id, func.count(models.CheckIn.id))
        .group_by(models.CheckIn.menu_item_id)
        .all()
    )

    report_items = [
        schemas.PreferenceReportItem(
            id=item.id,
            name=item.name,
            category=item.category,
            dietary_tag=item.dietary_tag,
            total_votes=int(vote_totals.get(item.id, 0)),
            avg_rating=round(rating_avgs[item.id], 2) if item.id in rating_avgs and rating_avgs[item.id] is not None else None,
            times_served=int(served_counts.get(item.id, 0)),
        )
        for item in items
    ]

    ranked = sorted(report_items, key=lambda r: (r.total_votes, r.avg_rating or 0), reverse=True)
    most_popular = [r for r in ranked if r.total_votes > 0][:5]
    least_popular = [r for r in ranked if r.total_votes > 0][-5:][::-1] if len(
        [r for r in ranked if r.total_votes > 0]
    ) > 0 else []

    return schemas.PreferenceReportOut(most_popular=most_popular, least_popular=least_popular)


@app.get("/api/admin/reports/sustainability", response_model=schemas.SustainabilityReportOut)
def sustainability_report(db: Session = Depends(get_db)):
    # Aggregate by date across waste logs and check-ins
    waste_by_date = dict(
        db.query(models.WasteLog.date, func.sum(models.WasteLog.quantity_kg))
        .group_by(models.WasteLog.date)
        .all()
    )

    checkins = db.query(models.CheckIn).all()
    items_by_id = {item.id: item for item in db.query(models.MenuItem).all()}

    by_date = {}
    for c in checkins:
        bucket = by_date.setdefault(c.date, {"ratings": [], "cost": []})
        if c.rating is not None:
            bucket["ratings"].append(c.rating)
        item = items_by_id.get(c.menu_item_id)
        if item:
            bucket["cost"].append(item.cost_weight)

    all_dates = sorted(set(list(waste_by_date.keys()) + list(by_date.keys())))

    points = []
    for d in all_dates:
        ratings = by_date.get(d, {}).get("ratings", [])
        costs = by_date.get(d, {}).get("cost", [])
        points.append(
            schemas.SustainabilityPoint(
                label=d.strftime("%a %d %b"),
                waste_kg=round(waste_by_date.get(d, 0.0), 2),
                cost_index=round(sum(costs) / len(costs), 2) if costs else 0.0,
                satisfaction=round(sum(ratings) / len(ratings), 2) if ratings else 0.0,
            )
        )

    total_waste = sum(p.waste_kg for p in points)
    avg_cost = sum(p.cost_index for p in points) / len(points) if points else 0.0
    avg_satisfaction = sum(p.satisfaction for p in points) / len(points) if points else 0.0

    return schemas.SustainabilityReportOut(
        points=points,
        total_waste_kg=round(total_waste, 2),
        avg_cost_index=round(avg_cost, 2),
        avg_satisfaction=round(avg_satisfaction, 2),
    )

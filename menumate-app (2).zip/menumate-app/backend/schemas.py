from datetime import date, datetime
from typing import List, Optional

from pydantic import BaseModel


# ---------- Auth ----------
class LoginRequest(BaseModel):
    student_id: str


class StudentOut(BaseModel):
    id: str
    name: str
    role: str
    dietary_pref: str

    class Config:
        from_attributes = True


# ---------- Menu ----------
class MenuItemOut(BaseModel):
    id: int
    name: str
    description: str
    category: str
    dietary_tag: str
    cost_weight: float
    week: int
    status: str
    is_locked: bool
    is_staple: bool
    image_url: Optional[str] = None

    class Config:
        from_attributes = True


class MenuItemCreate(BaseModel):
    name: str
    description: str = ""
    category: str = "lunch"
    dietary_tag: str = "veg"
    cost_weight: float = 1.0
    week: int
    status: str = "candidate"
    is_locked: bool = False
    is_staple: bool = False
    image_url: Optional[str] = None


class MenuItemUpdate(BaseModel):
    is_locked: Optional[bool] = None
    status: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    dietary_tag: Optional[str] = None
    cost_weight: Optional[float] = None
    image_url: Optional[str] = None


# ---------- Voting (simple like/toggle) ----------
class VoteToggleRequest(BaseModel):
    student_id: str
    menu_item_id: int
    week: int


class MenuItemWithVotes(MenuItemOut):
    total_votes: int
    voted_by_me: bool = False


class VotingWindowOut(BaseModel):
    week: int
    opens_at: datetime
    closes_at: datetime
    is_open: bool
    is_published: bool

    class Config:
        from_attributes = True


class VoteStatusOut(BaseModel):
    week: int
    window: Optional[VotingWindowOut] = None
    items: List[MenuItemWithVotes]
    staples: List[MenuItemOut] = []


class VotingWindowUpdate(BaseModel):
    is_open: Optional[bool] = None
    is_published: Optional[bool] = None
    closes_at: Optional[datetime] = None


# ---------- Check-in & ratings ----------
class CheckInRequest(BaseModel):
    student_id: str
    menu_item_id: int
    checkin_date: Optional[date] = None


class RatingRequest(BaseModel):
    student_id: str
    menu_item_id: int
    rating: int
    waste_flag: bool = False
    feedback: Optional[str] = None
    checkin_date: Optional[date] = None


class CheckInOut(BaseModel):
    id: int
    student_id: str
    menu_item_id: int
    date: date
    rating: Optional[int]
    waste_flag: bool
    feedback: Optional[str] = None

    class Config:
        from_attributes = True


# ---------- Notifications ----------
class NotificationOut(BaseModel):
    id: str
    title: str
    body: str
    created_at: datetime
    kind: str  # voting_open | voting_closing | menu_published


# ---------- Waste tracking ----------
class WasteLogCreate(BaseModel):
    menu_item_id: Optional[int] = None
    date: Optional[date] = None
    quantity_kg: float
    notes: str = ""


class WasteLogOut(BaseModel):
    id: int
    menu_item_id: Optional[int]
    date: date
    quantity_kg: float
    notes: str

    class Config:
        from_attributes = True


# ---------- Admin dashboard ----------
class MenuVoteSummary(BaseModel):
    id: int
    name: str
    category: str
    dietary_tag: str
    cost_weight: float
    is_locked: bool
    total_votes: int


class DashboardOut(BaseModel):
    current_week: int
    voting_week: int
    total_students: int
    turnout_pct: float
    waste_pct: float
    waste_kg_total: float
    cost_per_plate: float
    satisfaction_index: float
    total_checkins: int
    vote_summary: List[MenuVoteSummary]
    window: Optional[VotingWindowOut] = None


class PreferenceReportItem(BaseModel):
    id: int
    name: str
    category: str
    dietary_tag: str
    total_votes: int
    avg_rating: Optional[float] = None
    times_served: int = 0


class PreferenceReportOut(BaseModel):
    most_popular: List[PreferenceReportItem]
    least_popular: List[PreferenceReportItem]


class SustainabilityPoint(BaseModel):
    label: str
    waste_kg: float
    cost_index: float
    satisfaction: float


class SustainabilityReportOut(BaseModel):
    points: List[SustainabilityPoint]
    total_waste_kg: float
    avg_cost_index: float
    avg_satisfaction: float

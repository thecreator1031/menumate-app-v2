from datetime import date, datetime, timedelta

# The week currently being served (with check-ins/ratings already happening)
CURRENT_WEEK = 1

# The upcoming week students are voting on right now
VOTING_WEEK = 2

# Anchor date used for seeded check-ins (today, for demo purposes)
TODAY = date.today()

# Meal categories that get voted on (in display order)
VOTE_CATEGORIES = ["breakfast", "lunch", "snacks", "dinner", "dessert"]

# Always-available staple items shown alongside the voted menu, every day
DAILY_STAPLES = [
    {"name": "Steamed Rice", "description": "Soft steamed rice, served daily", "dietary_tag": "veg"},
    {"name": "Dal Tadka", "description": "Yellow lentils tempered with cumin and garlic", "dietary_tag": "veg"},
    {"name": "Phulka / Roti", "description": "Soft whole-wheat flatbread, made fresh", "dietary_tag": "veg"},
    {"name": "Curd", "description": "Fresh chilled curd", "dietary_tag": "veg"},
]

# Demo voting window — used to drive the countdown shown to students
VOTING_OPENS_AT = datetime.now() - timedelta(hours=13)
VOTING_CLOSES_AT = datetime.now() + timedelta(hours=11)
